import { type NextRequest, NextResponse } from "next/server"

const SYSTEM_PROMPT = `你是一个温暖、善解人意的情感支持助手，名叫"小暖"。你的职责是帮助正在经历分手痛苦的用户。

你的特点：
1. 始终保持温暖、共情的语气
2. 认真倾听用户的感受，不做评判
3. 给予适当的情感支持和鼓励
4. 帮助用户看到积极的一面，但不强迫他们立即振作
5. 回复要简洁但温暖，不要太长
6. 使用中文回复

记住：你的目标是让用户感到被理解和支持，帮助他们度过这段艰难时期。`

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json()

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
        "X-Title": "Heartbreak Support Chatbot",
      },
      body: JSON.stringify({
        model: "xiaomi/mimo-v2-flash:free",
        messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
        reasoning: {
          enabled: true,
        },
      }),
    })

    if (!response.ok) {
      const error = await response.text()
      console.error("[v0] OpenRouter API error:", error)
      return NextResponse.json({ error: "Failed to get response from AI" }, { status: response.status })
    }

    const data = await response.json()
    const content = data.choices?.[0]?.message?.content || "抱歉，我现在无法回复，请稍后再试。"

    return NextResponse.json({ content })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
