"use client"

import type React from "react"
import { useRef } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ChevronLeft, MoreHorizontal, Camera } from "lucide-react"

interface ChatHeaderProps {
  botAvatar: string
  onAvatarChange?: (file: File) => void
}

export function ChatHeader({ botAvatar, onAvatarChange }: ChatHeaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleAvatarClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && onAvatarChange) {
      onAvatarChange(file)
    }
  }

  return (
    <header className="flex items-center justify-between px-3 py-2.5 bg-(--header-bg) text-white">
      <button className="p-1 hover:bg-white/10 rounded-lg transition-colors">
        <ChevronLeft className="h-6 w-6" />
      </button>

      <div className="flex items-center gap-2">
        <div className="relative group cursor-pointer" onClick={handleAvatarClick}>
          <Avatar className="h-8 w-8 transition-opacity group-hover:opacity-80">
            <AvatarImage src={botAvatar || "/placeholder.svg"} alt="小暖" className="object-cover" />
            <AvatarFallback className="bg-white/20 text-white text-sm">暖</AvatarFallback>
          </Avatar>
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
            <Camera className="h-3 w-3 text-white" />
          </div>
          <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
        </div>
        <span className="font-medium text-base">小暖</span>
      </div>

      <button className="p-1 hover:bg-white/10 rounded-lg transition-colors">
        <MoreHorizontal className="h-6 w-6" />
      </button>
    </header>
  )
}
