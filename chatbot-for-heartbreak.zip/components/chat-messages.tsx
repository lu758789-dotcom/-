import type React from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import type { Message } from "@/types/chat"

interface ChatMessagesProps {
  messages: Message[]
  botAvatar: string
  isTyping: boolean
  messagesEndRef: React.RefObject<HTMLDivElement>
}

export function ChatMessages({ messages, botAvatar, isTyping, messagesEndRef }: ChatMessagesProps) {
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="flex-1 overflow-y-auto px-3 py-3 space-y-3 bg-(--chat-bg)">
      {messages.map((message, index) => {
        const showTime =
          index === 0 ||
          new Date(messages[index].timestamp).getTime() - new Date(messages[index - 1].timestamp).getTime() > 300000

        return (
          <div key={message.id}>
            {showTime && (
              <div className="flex justify-center my-3">
                <span className="text-xs text-muted-foreground bg-black/5 px-2 py-0.5 rounded">
                  {formatTime(message.timestamp)}
                </span>
              </div>
            )}
            <div
              className={cn("flex gap-2 max-w-[80%]", message.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto")}
            >
              <Avatar className="h-10 w-10 flex-shrink-0">
                {message.role === "assistant" ? (
                  <>
                    <AvatarImage src={botAvatar || "/placeholder.svg"} alt="小暖" className="object-cover" />
                    <AvatarFallback className="bg-(--wechat-green) text-white text-sm">暖</AvatarFallback>
                  </>
                ) : (
                  <AvatarFallback className="bg-blue-500 text-white text-sm">我</AvatarFallback>
                )}
              </Avatar>
              <div className="relative">
                <div
                  className={cn(
                    "relative rounded px-3 py-2.5 text-sm leading-relaxed whitespace-pre-wrap",
                    message.role === "user" ? "bg-(--wechat-green) text-white" : "bg-white text-foreground",
                  )}
                >
                  {/* Triangle pointer */}
                  <span
                    className={cn(
                      "absolute top-3 w-0 h-0 border-[6px]",
                      message.role === "user"
                        ? "right-[-10px] border-l-(--wechat-green) border-t-transparent border-b-transparent border-r-transparent"
                        : "left-[-10px] border-r-white border-t-transparent border-b-transparent border-l-transparent",
                    )}
                  />
                  {message.content}
                </div>
              </div>
            </div>
          </div>
        )
      })}

      {isTyping && (
        <div className="flex gap-2 max-w-[80%] mr-auto">
          <Avatar className="h-10 w-10 flex-shrink-0">
            <AvatarImage src={botAvatar || "/placeholder.svg"} alt="小暖" className="object-cover" />
            <AvatarFallback className="bg-(--wechat-green) text-white text-sm">暖</AvatarFallback>
          </Avatar>
          <div className="relative">
            <div className="relative bg-white rounded px-4 py-3">
              <span className="absolute left-[-10px] top-3 w-0 h-0 border-[6px] border-r-white border-t-transparent border-b-transparent border-l-transparent" />
              <div className="flex gap-1">
                <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce [animation-delay:-0.3s]"></span>
                <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce [animation-delay:-0.15s]"></span>
                <span className="w-2 h-2 rounded-full bg-gray-400 animate-bounce"></span>
              </div>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  )
}
