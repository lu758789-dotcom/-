"use client"

import type React from "react"
import { useState } from "react"
import { Mic, Smile, Plus } from "lucide-react"

interface ChatInputProps {
  onSendMessage: (message: string) => void
  disabled?: boolean
}

export function ChatInput({ onSendMessage, disabled }: ChatInputProps) {
  const [input, setInput] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim() && !disabled) {
      onSendMessage(input.trim())
      setInput("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e)
    }
  }

  return (
    <div className="flex items-center gap-2 px-3 py-2 bg-(--secondary) border-t border-border">
      <button type="button" className="p-2 text-muted-foreground hover:text-foreground transition-colors">
        <Mic className="h-6 w-6" />
      </button>

      <form onSubmit={handleSubmit} className="flex-1">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="输入你想说的话..."
          disabled={disabled}
          className="w-full px-3 py-2 bg-white rounded text-sm text-foreground placeholder:text-muted-foreground focus:outline-none disabled:opacity-50"
        />
      </form>

      <button type="button" className="p-2 text-muted-foreground hover:text-foreground transition-colors">
        <Smile className="h-6 w-6" />
      </button>

      <button type="button" className="p-2 text-muted-foreground hover:text-foreground transition-colors">
        <Plus className="h-6 w-6" />
      </button>
    </div>
  )
}
