"use client"

import { useState } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Brand {
  id: string
  name: string
  slogan: string
  foundedYear: number
  founder: string
  headquarters: string
  description: string
  highlights: string[]
  color: string
  image: string
}

export function BrandCard({ brand }: { brand: Brand }) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <Card
      className="group relative overflow-hidden border-border bg-card transition-all duration-300 hover:border-primary/50 hover:shadow-lg hover:shadow-primary/10"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-48 overflow-hidden">
        <div className={`absolute inset-0 bg-gradient-to-br ${brand.color} opacity-80`} />
        <Image
          src={brand.image || "/placeholder.svg"}
          alt={brand.name}
          fill
          className={`object-cover transition-transform duration-500 ${isHovered ? "scale-110" : "scale-100"}`}
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <h3 className="text-4xl font-bold text-foreground drop-shadow-lg md:text-5xl">{brand.name}</h3>
        </div>
      </div>

      <CardContent className="p-6">
        <p className="mb-4 text-lg font-medium text-primary">"{brand.slogan}"</p>

        <p className="mb-4 text-sm leading-relaxed text-muted-foreground">{brand.description}</p>

        <div className="mb-4 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">成立年份</span>
            <span className="font-medium text-foreground">{brand.foundedYear}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">创始人</span>
            <span className="font-medium text-foreground">{brand.founder}</span>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {brand.highlights.map((highlight, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {highlight}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
