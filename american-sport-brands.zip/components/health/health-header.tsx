"use client"

import { Watch, Bell, User, Wifi, WifiOff } from "lucide-react"
import { Button } from "@/components/ui/button"

interface HealthHeaderProps {
  connectedWatch: string | null
  onConnectWatch: () => void
}

export function HealthHeader({ connectedWatch, onConnectWatch }: HealthHeaderProps) {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 md:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent">
            <Watch className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">健康监测中心</h1>
            <p className="text-xs text-muted-foreground">Health Monitor</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* 连接状态 */}
          <Button
            variant="outline"
            size="sm"
            onClick={onConnectWatch}
            className={`gap-2 ${connectedWatch ? "border-primary/50 bg-primary/10 text-primary" : "border-border"}`}
          >
            {connectedWatch ? (
              <>
                <Wifi className="h-4 w-4" />
                <span className="hidden sm:inline">{connectedWatch}</span>
                <span className="sm:hidden">已连接</span>
              </>
            ) : (
              <>
                <WifiOff className="h-4 w-4" />
                <span className="hidden sm:inline">连接手表</span>
                <span className="sm:hidden">连接</span>
              </>
            )}
          </Button>

          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-destructive" />
          </Button>

          <Button variant="ghost" size="icon">
            <User className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  )
}
