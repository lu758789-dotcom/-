"use client"

import { Flame, UtensilsCrossed } from "lucide-react"

interface CalorieFoodProps {
  calories: number
}

const foodEquivalents = [
  { name: "汉堡", calories: 250, emoji: "🍔" },
  { name: "薯条", calories: 320, emoji: "🍟" },
  { name: "可乐", calories: 140, emoji: "🥤" },
  { name: "苹果", calories: 95, emoji: "🍎" },
  { name: "米饭(一碗)", calories: 200, emoji: "🍚" },
  { name: "鸡蛋", calories: 78, emoji: "🥚" },
  { name: "牛奶(250ml)", calories: 150, emoji: "🥛" },
  { name: "香蕉", calories: 105, emoji: "🍌" },
  { name: "披萨(一片)", calories: 285, emoji: "🍕" },
  { name: "巧克力(50g)", calories: 270, emoji: "🍫" },
  { name: "面包(一片)", calories: 80, emoji: "🍞" },
  { name: "冰淇淋", calories: 207, emoji: "🍦" },
]

export function CalorieFood({ calories }: CalorieFoodProps) {
  // 计算等价的食物组合
  const getEquivalents = () => {
    const results: { food: (typeof foodEquivalents)[0]; count: number }[] = []
    const remaining = calories

    for (const food of foodEquivalents) {
      if (remaining >= food.calories) {
        const count = Math.floor(remaining / food.calories)
        if (count > 0) {
          results.push({ food, count: Math.min(count, 3) })
        }
      }
    }

    return results.slice(0, 6)
  }

  const equivalents = getEquivalents()

  return (
    <section className="mb-10">
      <div className="mb-6 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-red-500">
          <UtensilsCrossed className="h-5 w-5 text-white" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-foreground">卡路里换算</h2>
          <p className="text-sm text-muted-foreground">
            您今日消耗的 <span className="font-semibold text-primary">{calories} kcal</span> 相当于...
          </p>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {equivalents.map(({ food, count }) => (
          <div
            key={food.name}
            className="group flex items-center gap-4 rounded-2xl border border-border bg-card p-4 transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5"
          >
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-muted/50 text-3xl transition-transform group-hover:scale-110">
              {food.emoji}
            </div>
            <div className="flex-1">
              <div className="flex items-baseline gap-2">
                <span className="text-2xl font-bold text-foreground">{count}</span>
                <span className="text-muted-foreground">份</span>
                <span className="font-medium text-foreground">{food.name}</span>
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Flame className="h-3 w-3 text-orange-500" />
                <span>每份 {food.calories} kcal</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-2xl border border-border bg-gradient-to-r from-card to-secondary/30 p-6">
        <div className="flex flex-wrap items-center justify-center gap-2 text-lg">
          <span className="text-muted-foreground">今天你消耗的热量等于吃了</span>
          {equivalents.slice(0, 3).map(({ food, count }, index) => (
            <span key={food.name} className="inline-flex items-center gap-1">
              {index > 0 && <span className="text-muted-foreground">+</span>}
              <span className="text-2xl">{food.emoji}</span>
              <span className="font-bold text-primary">×{count}</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
