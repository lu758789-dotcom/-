"use client"

import { useState } from "react"
import { X, Search, Check, Bluetooth, Watch } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface WatchModalProps {
  isOpen: boolean
  onClose: () => void
  onConnect: (watchName: string) => void
}

const watchBrands = [
  {
    brand: "Apple",
    models: [
      { name: "Apple Watch Ultra 2", image: "⌚" },
      { name: "Apple Watch Series 9", image: "⌚" },
      { name: "Apple Watch SE", image: "⌚" },
    ],
  },
  {
    brand: "华为",
    models: [
      { name: "华为 Watch GT 4", image: "⌚" },
      { name: "华为 Watch 4 Pro", image: "⌚" },
      { name: "华为 Watch Fit 3", image: "⌚" },
      { name: "华为 Watch Ultimate", image: "⌚" },
    ],
  },
  {
    brand: "小米",
    models: [
      { name: "小米 Watch S3", image: "⌚" },
      { name: "小米手环 8 Pro", image: "⌚" },
      { name: "Redmi Watch 4", image: "⌚" },
    ],
  },
  {
    brand: "三星",
    models: [
      { name: "Galaxy Watch 6", image: "⌚" },
      { name: "Galaxy Watch 6 Classic", image: "⌚" },
      { name: "Galaxy Fit 3", image: "⌚" },
    ],
  },
  {
    brand: "Garmin",
    models: [
      { name: "Garmin Fenix 8", image: "⌚" },
      { name: "Garmin Venu 3", image: "⌚" },
      { name: "Garmin Forerunner 965", image: "⌚" },
      { name: "Garmin Epix Pro", image: "⌚" },
    ],
  },
  {
    brand: "OPPO",
    models: [
      { name: "OPPO Watch 4 Pro", image: "⌚" },
      { name: "OPPO Watch SE", image: "⌚" },
      { name: "OPPO Band 2", image: "⌚" },
    ],
  },
  {
    brand: "vivo",
    models: [
      { name: "vivo Watch 3", image: "⌚" },
      { name: "vivo Watch 3 ECG", image: "⌚" },
    ],
  },
  {
    brand: "Amazfit",
    models: [
      { name: "Amazfit GTR 4", image: "⌚" },
      { name: "Amazfit T-Rex Ultra", image: "⌚" },
      { name: "Amazfit Balance", image: "⌚" },
    ],
  },
]

export function WatchModal({ isOpen, onClose, onConnect }: WatchModalProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedWatch, setSelectedWatch] = useState<string | null>(null)
  const [connecting, setConnecting] = useState(false)

  if (!isOpen) return null

  const filteredBrands = watchBrands
    .map((brand) => ({
      ...brand,
      models: brand.models.filter(
        (model) =>
          model.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          brand.brand.toLowerCase().includes(searchQuery.toLowerCase()),
      ),
    }))
    .filter((brand) => brand.models.length > 0)

  const handleConnect = async () => {
    if (!selectedWatch) return
    setConnecting(true)
    // 模拟连接过程
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setConnecting(false)
    onConnect(selectedWatch)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* 背景遮罩 */}
      <div className="absolute inset-0 bg-background/80 backdrop-blur-sm" onClick={onClose} />

      {/* 弹窗内容 */}
      <div className="relative mx-4 max-h-[85vh] w-full max-w-2xl overflow-hidden rounded-3xl border border-border bg-card shadow-2xl">
        {/* 头部 */}
        <div className="sticky top-0 z-10 border-b border-border bg-card/95 px-6 py-4 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent">
                <Watch className="h-5 w-5 text-primary-foreground" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">连接智能手表</h2>
                <p className="text-xs text-muted-foreground">选择您的设备进行配对</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* 搜索框 */}
          <div className="relative mt-4">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="text"
              placeholder="搜索手表品牌或型号..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* 手表列表 */}
        <div className="max-h-[50vh] overflow-y-auto p-6">
          {filteredBrands.map((brand) => (
            <div key={brand.brand} className="mb-6 last:mb-0">
              <h3 className="mb-3 text-sm font-medium text-muted-foreground">{brand.brand}</h3>
              <div className="grid gap-2 sm:grid-cols-2">
                {brand.models.map((model) => (
                  <button
                    key={model.name}
                    onClick={() => setSelectedWatch(model.name)}
                    className={`flex items-center gap-3 rounded-xl border p-3 text-left transition-all duration-200 ${
                      selectedWatch === model.name
                        ? "border-primary bg-primary/10"
                        : "border-border bg-secondary/30 hover:border-primary/50 hover:bg-secondary/50"
                    }`}
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted/50 text-xl">
                      {model.image}
                    </div>
                    <span className="flex-1 text-sm font-medium text-foreground">{model.name}</span>
                    {selectedWatch === model.name && <Check className="h-4 w-4 text-primary" />}
                  </button>
                ))}
              </div>
            </div>
          ))}

          {filteredBrands.length === 0 && (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Watch className="mb-4 h-12 w-12 text-muted-foreground/50" />
              <p className="text-muted-foreground">未找到匹配的设备</p>
              <p className="text-sm text-muted-foreground/70">尝试搜索其他关键词</p>
            </div>
          )}
        </div>

        {/* 底部操作 */}
        <div className="sticky bottom-0 border-t border-border bg-card/95 px-6 py-4 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Bluetooth className="h-4 w-4" />
              <span>请确保蓝牙已开启</span>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={onClose}>
                取消
              </Button>
              <Button onClick={handleConnect} disabled={!selectedWatch || connecting} className="min-w-[100px]">
                {connecting ? (
                  <span className="flex items-center gap-2">
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                    连接中
                  </span>
                ) : (
                  "连接设备"
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
