"use client"

import type { LucideIcon } from "lucide-react"
import { TrendingUp, TrendingDown, Minus } from "lucide-react"

interface HealthMetricCardProps {
  metric: {
    id: string
    title: string
    value: string
    unit: string
    status: "normal" | "high" | "low" | "warning"
    icon: LucideIcon
    color: string
    trend: number[]
    description: string
  }
}

export function HealthMetricCard({ metric }: HealthMetricCardProps) {
  const Icon = metric.icon
  const lastTrend = metric.trend[metric.trend.length - 1]
  const prevTrend = metric.trend[metric.trend.length - 2]
  const trendDirection = lastTrend > prevTrend ? "up" : lastTrend < prevTrend ? "down" : "stable"

  const statusColors = {
    normal: "text-emerald-500",
    high: "text-red-500",
    low: "text-blue-500",
    warning: "text-amber-500",
  }

  const statusText = {
    normal: "正常",
    high: "偏高",
    low: "偏低",
    warning: "注意",
  }

  // 生成迷你图路径
  const maxVal = Math.max(...metric.trend)
  const minVal = Math.min(...metric.trend)
  const range = maxVal - minVal || 1
  const points = metric.trend
    .map((val, i) => {
      const x = (i / (metric.trend.length - 1)) * 60
      const y = 20 - ((val - minVal) / range) * 16
      return `${x},${y}`
    })
    .join(" ")

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border bg-card p-5 transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
      {/* 背景渐变 */}
      <div
        className={`absolute -right-8 -top-8 h-24 w-24 rounded-full bg-gradient-to-br ${metric.color} opacity-10 blur-2xl transition-opacity group-hover:opacity-20`}
      />

      <div className="relative">
        {/* 头部 */}
        <div className="mb-4 flex items-start justify-between">
          <div className={`rounded-xl bg-gradient-to-br ${metric.color} p-2.5`}>
            <Icon className="h-5 w-5 text-white" />
          </div>
          <div className={`flex items-center gap-1 text-xs font-medium ${statusColors[metric.status]}`}>
            {trendDirection === "up" && <TrendingUp className="h-3 w-3" />}
            {trendDirection === "down" && <TrendingDown className="h-3 w-3" />}
            {trendDirection === "stable" && <Minus className="h-3 w-3" />}
            {statusText[metric.status]}
          </div>
        </div>

        {/* 数值 */}
        <div className="mb-1">
          <span className="text-3xl font-bold text-foreground">{metric.value}</span>
          {metric.unit && <span className="ml-1 text-sm text-muted-foreground">{metric.unit}</span>}
        </div>

        <p className="mb-4 text-sm text-muted-foreground">{metric.title}</p>

        {/* 迷你趋势图 */}
        <div className="flex items-end justify-between">
          <svg width="60" height="24" className="text-primary/60">
            <polyline
              points={points}
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span className="text-xs text-muted-foreground">{metric.description}</span>
        </div>
      </div>
    </div>
  )
}
