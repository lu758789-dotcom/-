"use client"

import type { LucideIcon } from "lucide-react"

interface ActivityCardProps {
  metric: {
    id: string
    title: string
    value: string
    unit: string
    target: number
    current: number
    icon: LucideIcon
    color: string
  }
}

export function ActivityCard({ metric }: ActivityCardProps) {
  const Icon = metric.icon
  const percentage = Math.min((metric.current / metric.target) * 100, 100)
  const circumference = 2 * Math.PI * 45
  const strokeDashoffset = circumference - (percentage / 100) * circumference

  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
      <div
        className={`absolute -right-12 -top-12 h-32 w-32 rounded-full bg-gradient-to-br ${metric.color} opacity-10 blur-3xl transition-opacity group-hover:opacity-20`}
      />

      <div className="relative flex items-center gap-6">
        {/* 圆形进度 */}
        <div className="relative flex-shrink-0">
          <svg width="110" height="110" className="-rotate-90">
            {/* 背景圆 */}
            <circle
              cx="55"
              cy="55"
              r="45"
              fill="none"
              stroke="currentColor"
              strokeWidth="8"
              className="text-muted/30"
            />
            {/* 进度圆 */}
            <circle
              cx="55"
              cy="55"
              r="45"
              fill="none"
              stroke="url(#gradient)"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-500"
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop
                  offset="0%"
                  className={
                    metric.color.includes("orange")
                      ? "text-orange-500"
                      : metric.color.includes("emerald")
                        ? "text-emerald-500"
                        : "text-yellow-500"
                  }
                  style={{ stopColor: "currentColor" }}
                />
                <stop
                  offset="100%"
                  className={
                    metric.color.includes("red")
                      ? "text-red-500"
                      : metric.color.includes("teal")
                        ? "text-teal-500"
                        : "text-amber-500"
                  }
                  style={{ stopColor: "currentColor" }}
                />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <Icon
              className={`h-6 w-6 bg-gradient-to-br ${metric.color} bg-clip-text text-transparent`}
              style={{
                color: metric.color.includes("orange")
                  ? "#f97316"
                  : metric.color.includes("emerald")
                    ? "#10b981"
                    : "#eab308",
              }}
            />
            <span className="mt-1 text-xs text-muted-foreground">{Math.round(percentage)}%</span>
          </div>
        </div>

        {/* 数据 */}
        <div className="flex-1">
          <h3 className="mb-1 text-sm font-medium text-muted-foreground">{metric.title}</h3>
          <div className="mb-2">
            <span className="text-3xl font-bold text-foreground">{metric.value}</span>
            <span className="ml-1 text-sm text-muted-foreground">{metric.unit}</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>
              目标: {metric.target.toLocaleString()} {metric.unit}
            </span>
            <span className="text-primary">
              还差 {(metric.target - metric.current).toLocaleString()} {metric.unit}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}
