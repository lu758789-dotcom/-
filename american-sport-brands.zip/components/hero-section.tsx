"use client"

import { useState, useEffect } from "react"

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const slides = [
    { brand: "李宁", text: "一切皆有可能", color: "text-red-500" },
    { brand: "安踏", text: "永不止步", color: "text-blue-500" },
    { brand: "特步", text: "非一般的感觉", color: "text-emerald-500" },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 3000)
    return () => clearInterval(timer)
  }, [slides.length])

  return (
    <section className="relative flex min-h-[80vh] flex-col items-center justify-center overflow-hidden bg-background px-4">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent" />

      <div className="relative z-10 text-center">
        <p className="mb-4 text-sm font-medium uppercase tracking-widest text-muted-foreground">中国顶级运动品牌</p>
        <h1 className="mb-6 text-balance text-5xl font-bold tracking-tight text-foreground md:text-7xl lg:text-8xl">
          国货崛起
        </h1>

        <div className="mb-8 h-16 overflow-hidden">
          <div
            className="transition-transform duration-500 ease-out"
            style={{ transform: `translateY(-${currentSlide * 64}px)` }}
          >
            {slides.map((slide, index) => (
              <div key={index} className="flex h-16 items-center justify-center">
                <span className={`text-2xl font-medium md:text-3xl ${slide.color}`}>
                  {slide.brand}: {slide.text}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-center gap-2">
          {slides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`h-2 w-8 rounded-full transition-all ${currentSlide === index ? "bg-primary" : "bg-muted"}`}
              aria-label={`切换到第 ${index + 1} 张`}
            />
          ))}
        </div>
      </div>

      <div className="absolute bottom-8 animate-bounce">
        <svg className="h-6 w-6 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  )
}
