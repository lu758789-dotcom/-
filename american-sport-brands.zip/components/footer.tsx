export function Footer() {
  return (
    <footer className="border-t border-border bg-background px-4 py-12 md:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
          <div className="text-center md:text-left">
            <h3 className="mb-2 text-lg font-bold text-foreground">中国三大运动品牌</h3>
            <p className="text-sm text-muted-foreground">国货当自强，探索中国运动品牌的力量</p>
          </div>

          <div className="flex gap-8 text-sm text-muted-foreground">
            <a href="#" className="transition-colors hover:text-primary">
              李宁官网
            </a>
            <a href="#" className="transition-colors hover:text-primary">
              安踏官网
            </a>
            <a href="#" className="transition-colors hover:text-primary">
              特步官网
            </a>
          </div>
        </div>

        <div className="mt-8 border-t border-border pt-8 text-center text-xs text-muted-foreground">
          <p>© 2026 中国运动品牌展示. 仅供学习参考</p>
        </div>
      </div>
    </footer>
  )
}
