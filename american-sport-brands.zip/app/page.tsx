"use client"

import { useState } from "react"
import { HealthHeader } from "@/components/health/health-header"
import { HealthMetricCard } from "@/components/health/health-metric-card"
import { ActivityCard } from "@/components/health/activity-card"
import { CalorieFood } from "@/components/health/calorie-food"
import { WatchModal } from "@/components/health/watch-modal"
import { Heart, Activity, Moon, Droplets, Wind, Scale, Brain, AudioLines, Flame, Footprints, Zap } from "lucide-react"

export default function HealthDashboard() {
  const [isWatchModalOpen, setIsWatchModalOpen] = useState(false)
  const [connectedWatch, setConnectedWatch] = useState<string | null>(null)

  const healthMetrics = [
    {
      id: "heart-rate",
      title: "心率",
      value: "72",
      unit: "BPM",
      status: "normal" as const,
      icon: Heart,
      color: "from-rose-500 to-red-600",
      trend: [65, 70, 68, 72, 75, 71, 72],
      description: "静息心率正常范围",
    },
    {
      id: "blood-pressure",
      title: "血压",
      value: "120/80",
      unit: "mmHg",
      status: "normal" as const,
      icon: Activity,
      color: "from-blue-500 to-indigo-600",
      trend: [118, 122, 119, 120, 121, 120, 120],
      description: "收缩压/舒张压",
    },
    {
      id: "sleep",
      title: "睡眠",
      value: "7.5",
      unit: "小时",
      status: "normal" as const,
      icon: Moon,
      color: "from-violet-500 to-purple-600",
      trend: [6.5, 7, 8, 7.5, 6, 7.5, 7.5],
      description: "昨晚睡眠时长",
    },
    {
      id: "blood-sugar",
      title: "血糖",
      value: "5.2",
      unit: "mmol/L",
      status: "normal" as const,
      icon: Droplets,
      color: "from-amber-500 to-orange-600",
      trend: [5.0, 5.3, 5.1, 5.4, 5.2, 5.1, 5.2],
      description: "空腹血糖值",
    },
    {
      id: "blood-oxygen",
      title: "血氧饱和度",
      value: "98",
      unit: "%",
      status: "normal" as const,
      icon: Wind,
      color: "from-cyan-500 to-teal-600",
      trend: [97, 98, 98, 97, 99, 98, 98],
      description: "SpO2 正常范围",
    },
    {
      id: "weight",
      title: "体重",
      value: "68.5",
      unit: "kg",
      status: "normal" as const,
      icon: Scale,
      color: "from-emerald-500 to-green-600",
      trend: [69, 68.8, 68.6, 68.7, 68.5, 68.5, 68.5],
      description: "BMI: 22.3 正常",
    },
    {
      id: "stress",
      title: "压力指数",
      value: "35",
      unit: "分",
      status: "low" as const,
      icon: Brain,
      color: "from-pink-500 to-rose-600",
      trend: [45, 40, 38, 42, 35, 33, 35],
      description: "压力水平较低",
    },
    {
      id: "heart-sound",
      title: "心音检测",
      value: "正常",
      unit: "",
      status: "normal" as const,
      icon: AudioLines,
      color: "from-fuchsia-500 to-purple-600",
      trend: [1, 1, 1, 1, 1, 1, 1],
      description: "心音节律规整",
    },
  ]

  const activityMetrics = [
    {
      id: "calories",
      title: "消耗卡路里",
      value: "486",
      unit: "kcal",
      target: 600,
      current: 486,
      icon: Flame,
      color: "from-orange-500 to-red-500",
    },
    {
      id: "steps",
      title: "步数",
      value: "8,642",
      unit: "步",
      target: 10000,
      current: 8642,
      icon: Footprints,
      color: "from-emerald-500 to-teal-500",
    },
    {
      id: "intensity",
      title: "中高强度运动",
      value: "45",
      unit: "分钟",
      target: 60,
      current: 45,
      icon: Zap,
      color: "from-yellow-500 to-amber-500",
    },
  ]

  return (
    <main className="min-h-screen bg-background">
      <HealthHeader connectedWatch={connectedWatch} onConnectWatch={() => setIsWatchModalOpen(true)} />

      <div className="mx-auto max-w-7xl px-4 py-8 md:px-6 lg:px-8">
        {/* 健康指标网格 */}
        <section className="mb-10">
          <h2 className="mb-6 text-xl font-semibold text-foreground">健康指标</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {healthMetrics.map((metric) => (
              <HealthMetricCard key={metric.id} metric={metric} />
            ))}
          </div>
        </section>

        {/* 运动数据 */}
        <section className="mb-10">
          <h2 className="mb-6 text-xl font-semibold text-foreground">今日运动</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {activityMetrics.map((metric) => (
              <ActivityCard key={metric.id} metric={metric} />
            ))}
          </div>
        </section>

        {/* 卡路里食物比喻 */}
        <CalorieFood calories={486} />
      </div>

      <WatchModal
        isOpen={isWatchModalOpen}
        onClose={() => setIsWatchModalOpen(false)}
        onConnect={(watch) => {
          setConnectedWatch(watch)
          setIsWatchModalOpen(false)
        }}
      />
    </main>
  )
}
