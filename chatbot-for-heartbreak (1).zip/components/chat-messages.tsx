import type React from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import type { Message } from "@/types/chat"

interface ChatMessagesProps {
  messages: Message[]
  botAvatar: string
  isTyping: boolean
  messagesEndRef: React.RefObject<HTMLDivElement>
}

export function ChatMessages({ messages, botAvatar, isTyping, messagesEndRef }: ChatMessagesProps) {
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4 bg-background">
      {messages.length === 0 && (
        <div className="flex flex-col items-center justify-center h-full text-center">
          <div className="max-w-md">
            <div className="text-5xl mb-4">💭</div>
            <h2 className="text-2xl font-semibold text-foreground mb-3">Start Your Conversation</h2>
            <p className="text-base text-muted-foreground">
              Share your thoughts, feelings, or questions. I'm here to listen and support you with care and
              understanding.
            </p>
          </div>
        </div>
      )}

      {messages.map((message, index) => {
        const showTime =
          index === 0 ||
          new Date(messages[index].timestamp).getTime() - new Date(messages[index - 1].timestamp).getTime() > 300000

        return (
          <div key={message.id}>
            {showTime && (
              <div className="flex justify-center my-4">
                <span className="text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full">
                  {formatTime(message.timestamp)}
                </span>
              </div>
            )}
            <div className={cn("flex gap-3 mb-2", message.role === "user" ? "justify-end" : "justify-start")}>
              {message.role === "assistant" && (
                <Avatar className="h-10 w-10 flex-shrink-0">
                  <AvatarImage src={botAvatar || "/placeholder.svg"} alt="Zhiyu" className="object-cover" />
                  <AvatarFallback className="bg-primary text-primary-foreground text-sm">Z</AvatarFallback>
                </Avatar>
              )}
              <div
                className={cn(
                  "rounded-2xl px-4 py-3 max-w-lg text-sm leading-relaxed",
                  message.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-foreground border border-border",
                )}
              >
                {message.content}
              </div>
            </div>
          </div>
        )
      })}

      {isTyping && (
        <div className="flex gap-3">
          <Avatar className="h-10 w-10 flex-shrink-0">
            <AvatarImage src={botAvatar || "/placeholder.svg"} alt="Zhiyu" className="object-cover" />
            <AvatarFallback className="bg-primary text-primary-foreground text-sm">Z</AvatarFallback>
          </Avatar>
          <div className="rounded-2xl px-4 py-3 bg-muted border border-border">
            <div className="flex gap-1.5">
              <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce [animation-delay:-0.3s]"></span>
              <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce [animation-delay:-0.15s]"></span>
              <span className="w-2 h-2 rounded-full bg-muted-foreground animate-bounce"></span>
            </div>
          </div>
        </div>
      )}

      <div ref={messagesEndRef} />
    </div>
  )
}
