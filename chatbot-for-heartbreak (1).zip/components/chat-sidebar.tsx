"use client"

import type React from "react"
import { useRef, useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Camera, Edit2 } from "lucide-react"

interface ChatSidebarProps {
  botAvatar: string
  botName: string
  onAvatarChange?: (file: File) => void
  onBotNameChange?: (name: string) => void
}

export function ChatSidebar({ botAvatar, botName, onAvatarChange, onBotNameChange }: ChatSidebarProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isEditingName, setIsEditingName] = useState(false)
  const [editingName, setEditingName] = useState(botName)

  const handleAvatarClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && onAvatarChange) {
      onAvatarChange(file)
    }
  }

  const handleNameClick = () => {
    setIsEditingName(true)
  }

  const handleNameInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditingName(e.target.value)
  }

  const handleNameInputBlur = () => {
    if (editingName.trim()) {
      onBotNameChange?.(editingName.trim())
    } else {
      setEditingName(botName)
    }
    setIsEditingName(false)
  }

  const handleNameInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleNameInputBlur()
    } else if (e.key === "Escape") {
      setEditingName(botName)
      setIsEditingName(false)
    }
  }

  return (
    <header className="bg-card border-b border-border px-6 py-4 flex items-center gap-4">
      <div className="relative group cursor-pointer" onClick={handleAvatarClick}>
        <Avatar className="h-16 w-16 transition-opacity group-hover:opacity-80">
          <AvatarImage src={botAvatar || "/placeholder.svg"} alt={botName} className="object-cover" />
          <AvatarFallback className="bg-primary text-primary-foreground text-lg">{botName.charAt(0)}</AvatarFallback>
        </Avatar>
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
          <Camera className="h-5 w-5 text-white" />
        </div>
        <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
      </div>

      <div className="flex-1">
        {isEditingName ? (
          <input
            type="text"
            value={editingName}
            onChange={handleNameInputChange}
            onBlur={handleNameInputBlur}
            onKeyDown={handleNameInputKeyDown}
            autoFocus
            className="w-full px-3 py-2 text-xl font-bold bg-muted text-foreground rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        ) : (
          <div className="flex items-center gap-2 group">
            <h2 className="text-xl font-bold text-foreground">{botName}</h2>
            <button
              onClick={handleNameClick}
              className="p-1 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-muted transition-all"
            >
              <Edit2 className="h-4 w-4 text-muted-foreground" />
            </button>
          </div>
        )}
        <p className="text-sm text-muted-foreground">Your supportive companion</p>
      </div>

      <div className="flex gap-3">
        <div className="bg-muted rounded-lg p-3 text-center min-w-max">
          <div className="font-semibold text-sm text-foreground">Always</div>
          <div className="text-xs text-muted-foreground">Available</div>
        </div>
        <div className="bg-muted rounded-lg p-3 text-center min-w-max">
          <div className="font-semibold text-sm text-foreground">100%</div>
          <div className="text-xs text-muted-foreground">Confidential</div>
        </div>
        <div className="bg-muted rounded-lg p-3 text-center min-w-max">
          <div className="font-semibold text-sm text-foreground">Deep</div>
          <div className="text-xs text-muted-foreground">Listening</div>
        </div>
      </div>
    </header>
  )
}
