"use client"

import { useState, useRef, useEffect } from "react"
import { ChatMessages } from "./chat-messages"
import { ChatInput } from "./chat-input"
import type { Message } from "@/types/chat"

const DEFAULT_BOT_AVATAR = "/images/img-v3-02tu-5a7d4c3c-b9c4-4307-a59f-816363651a8g.jpg"
const DEFAULT_BOT_NAME = "知予"

export function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([])
  const [isTyping, setIsTyping] = useState(false)
  const [botAvatar, setBotAvatar] = useState(DEFAULT_BOT_AVATAR)
  const [botName, setBotName] = useState(DEFAULT_BOT_NAME)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleAvatarChange = (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      if (e.target?.result) {
        setBotAvatar(e.target.result as string)
      }
    }
    reader.readAsDataURL(file)
  }

  const handleBotNameChange = (newName: string) => {
    setBotName(newName)
  }

  const generateResponse = async (userMessage: string, allMessages: Message[]): Promise<string> => {
    try {
      const apiMessages = allMessages.map((msg) => ({
        role: msg.role,
        content: msg.content,
      }))

      apiMessages.push({
        role: "user",
        content: userMessage,
      })

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ messages: apiMessages, botName }),
      })

      if (!response.ok) {
        throw new Error("API request failed")
      }

      const data = await response.json()
      return data.content
    } catch (error) {
      console.error("[v0] Error calling chat API:", error)
      return "抱歉，我暂时无法回复。请检查网络连接后再试一次，或者稍后再来找我聊聊。"
    }
  }

  const handleSendMessage = async (content: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setIsTyping(true)

    const response = await generateResponse(content, messages)

    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: response,
      role: "assistant",
      timestamp: new Date(),
    }

    setIsTyping(false)
    setMessages((prev) => [...prev, botMessage])
  }

  return (
    <div className="flex flex-col h-screen w-full bg-background">
      <div className="bg-header p-4">
        {" "}
        {/* New header section */}
        <h1 className="text-2xl font-bold">Chat with {botName}</h1>
      </div>
      <div className="flex-1 flex flex-col overflow-hidden">
        <ChatMessages messages={messages} botAvatar={botAvatar} isTyping={isTyping} messagesEndRef={messagesEndRef} />
        <ChatInput onSendMessage={handleSendMessage} disabled={isTyping} />
      </div>
    </div>
  )
}
