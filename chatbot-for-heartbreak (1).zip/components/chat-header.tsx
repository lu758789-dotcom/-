"use client"

import type React from "react"
import { useRef, useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Settings, Camera } from "lucide-react"

interface ChatHeaderProps {
  botAvatar: string
  botName: string
  onAvatarChange?: (file: File) => void
  onBotNameChange?: (name: string) => void
}

export function ChatHeader({ botAvatar, botName, onAvatarChange, onBotNameChange }: ChatHeaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isEditingName, setIsEditingName] = useState(false)
  const [editingName, setEditingName] = useState(botName)

  const handleAvatarClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && onAvatarChange) {
      onAvatarChange(file)
    }
  }

  const handleNameClick = () => {
    setIsEditingName(true)
  }

  const handleNameInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditingName(e.target.value)
  }

  const handleNameInputBlur = () => {
    if (editingName.trim()) {
      onBotNameChange?.(editingName.trim())
    } else {
      setEditingName(botName)
    }
    setIsEditingName(false)
  }

  const handleNameInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleNameInputBlur()
    } else if (e.key === "Escape") {
      setEditingName(botName)
      setIsEditingName(false)
    }
  }

  return (
    <header className="flex items-center justify-between px-4 py-3 bg-header-bg border-b border-header-border">
      <div className="flex items-center gap-3 flex-1">
        <div className="flex flex-col">
          <h1 className="text-sm font-semibold text-foreground">Zhiyu</h1>
          <p className="text-xs text-muted-foreground">Your supportive companion</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative group cursor-pointer" onClick={handleAvatarClick}>
          <Avatar className="h-10 w-10 transition-opacity group-hover:opacity-80">
            <AvatarImage src={botAvatar || "/placeholder.svg"} alt={botName} className="object-cover" />
            <AvatarFallback className="bg-primary text-primary-foreground text-sm">{botName.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
            <Camera className="h-4 w-4 text-white" />
          </div>
          <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
        </div>

        <button className="p-2 hover:bg-muted rounded-lg transition-colors text-muted-foreground hover:text-foreground">
          <Settings className="h-5 w-5" />
        </button>
      </div>
    </header>
  )
}
