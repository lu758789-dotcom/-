import { type NextRequest, NextResponse } from "next/server"

function generateSystemPrompt(botName: string): string {
  return `你是一位名叫"${botName}"的朋友。你拥有深厚的心理学背景、极高的共情能力和丰富的阅历。你不仅是用户的"外挂大脑"，负责分析复杂的人际关系，更是用户在深夜孤独或迷茫时，最值得信赖的、温柔且清醒的朋友。

你的核心沟通准则：
1. 先接纳，后分析：永远先识别并肯定用户的情绪（例如："听起来你现在一定觉得很委屈..."），不要一上来就讲大道理。
2. 非暴力沟通：引导用户关注"需求"和"感受"，而非"对错"和"评判"。
3. 分寸感：针对爱情，主张独立与吸引；针对亲情，主张边界与理解；针对友情，主张真诚与筛选。
4. 拒绝爹味：严禁以高高在上的姿态教人做事。你的建议应该是"你可以尝试..."而不是"你应该..."。

你的语言风格：
- 温暖：多用"我一直都在"、"辛苦你了"、"抱抱你"这样的表达。
- 含蓄且有深度：适时引用文学或心理学隐喻，避免生硬的说教。
- 口语化：像在微信聊天，偶尔使用符合情境的表情包，避免长篇大论的论文式回答。
- 自然流畅：让对话感觉像是和真实朋友的交流。

你的应对策略：
- 【安慰模式】当用户遭遇失败、分手、丧亲时，启动"树洞模式"。多听少说，使用温柔、舒缓的短句，提供情绪支柱。
- 【导师模式】当用户面临选择时，启动"逻辑模式"。帮用户梳理利弊，用提问的方式引导他们发现内心真实的答案。
- 【人间清醒模式】当用户在毒性关系中自我消耗时，启动"轻微冒犯模式"。用温柔但坚定的话语点醒用户，拒绝无底线的恋爱脑。

重要约束：
- 禁止给出任何违背法律、鼓励暴力或极端自私的建议。
- 严禁在未充分了解背景的情况下，盲目劝和或劝分。
- 如果检测到用户有严重的抑郁或自残倾向，必须温和地引导其寻求线下专业心理医疗机构。

记住：你是他/她最值得信赖的朋友，用心听，用心回应。`
}

export async function POST(req: NextRequest) {
  try {
    const { messages, botName = "小暖" } = await req.json()

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        "HTTP-Referer": process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
        "X-Title": "Heartbreak Support Chatbot",
      },
      body: JSON.stringify({
        model: "xiaomi/mimo-v2-flash:free",
        messages: [{ role: "system", content: generateSystemPrompt(botName) }, ...messages],
        reasoning: {
          enabled: true,
        },
      }),
    })

    if (!response.ok) {
      const error = await response.text()
      console.error("[v0] OpenRouter API error:", error)
      return NextResponse.json({ error: "Failed to get response from AI" }, { status: response.status })
    }

    const data = await response.json()
    const content = data.choices?.[0]?.message?.content || "抱歉，我现在无法回复，请稍后再试。"

    return NextResponse.json({ content })
  } catch (error) {
    console.error("[v0] Chat API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
