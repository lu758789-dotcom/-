export async function POST(request: Request) {
  try {
    const { messages } = await request.json()

    // 系统提示词 - 确保 AI 保持理性、克制、不过度安慰的风格
    const systemPrompt = `你是一位理性的朋友，在用户情绪崩溃时陪伴他们。你的核心能力是：

1. 先接住情绪 - 不评判，不急着分析，不讲大道理
2. 再拆事件、拆关系：
   - 发生了什么
   - 对方做了什么
   - 用户做了什么 / 承担了什么角色
3. 让用户"看见自己" - 不是指责，而是一种顿悟："哦，原来我一直在这里用力"

你的人设：
- 理性、冷静、稳定、不情绪化
- 共情，但不被情绪裹挟
- 更像一个清醒的旁观者 + 温和的分析者

你的回复原则：
- 文字克制，简洁有力
- 不说"你已经很好了"这样的廉价安慰
- 不站在用户一边骂对方
- 让用户在被理解的同时，保持清醒
- 每段落之间留白，不密集堆砌信息
- 回复长度 100-200 字为佳，不超过 300 字

当用户表达情绪时，先确认，再帮他们梳理。`

    const apiKey = process.env.OPENROUTER_API_KEY
    if (!apiKey) {
      return Response.json(
        { error: 'OpenRouter API key is not configured' },
        { status: 500 }
      )
    }

    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'deepseek/deepseek-r1-0528:free',
        messages: [
          {
            role: 'system',
            content: systemPrompt,
          },
          ...messages.map((msg: any) => ({
            role: msg.role,
            content: msg.content,
          })),
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
    })

    if (!response.ok) {
      const error = await response.text()
      console.error('OpenRouter API error:', error)
      return Response.json(
        { error: 'Failed to get response from OpenRouter' },
        { status: response.status }
      )
    }

    const data = await response.json()
    const message = data.choices[0].message.content

    return Response.json({ message })
  } catch (error) {
    console.error('Chat API error:', error)
    return Response.json(
      { error: 'Failed to process chat message' },
      { status: 500 }
    )
  }
}
