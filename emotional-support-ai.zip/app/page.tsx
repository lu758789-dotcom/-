'use client'

import { useState } from 'react'
import ChatWindow from '@/components/ChatWindow'
import MessageInput from '@/components/MessageInput'

export default function Home() {
  const [messages, setMessages] = useState<Array<{
    id: string
    role: 'user' | 'assistant'
    content: string
    timestamp: Date
  }>>([])
  const [isLoading, setIsLoading] = useState(false)

  const handleSendMessage = async (content: string) => {
    const userMessage = {
      id: Date.now().toString(),
      role: 'user' as const,
      content,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, userMessage])
    setIsLoading(true)

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMessage].map(m => ({
            role: m.role,
            content: m.content
          }))
        })
      })

      const data = await response.json()
      
      if (data.message) {
        setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: data.message,
          timestamp: new Date()
        }])
      }
    } catch (error) {
      console.error('Error:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="h-screen w-screen bg-background flex flex-col overflow-hidden">
      {/* Header with Moon and Brand */}
      <div className="relative h-24 border-b border-border/20 flex items-center px-8">
        {/* Subtle moon glow - realistic light */}
        <div className="absolute top-3 left-6 w-24 h-24 rounded-full bg-slate-200/8 blur-3xl pointer-events-none"></div>
        <div className="absolute top-5 left-8 w-16 h-16 rounded-full bg-slate-100/12 blur-2xl pointer-events-none"></div>
        
        {/* Moon - soft luminous circle */}
        <div className="absolute top-6 left-10 w-12 h-12 rounded-full bg-slate-100/35 shadow-lg" style={{
          boxShadow: '0 0 20px rgba(226, 232, 240, 0.15), inset -2px -2px 8px rgba(0, 0, 0, 0.3)'
        }}></div>
        
        {/* Brand text */}
        <div className="relative z-10 flex items-center gap-4">
          <span className="text-xl font-medium text-foreground/95 tracking-wide">朋友</span>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <ChatWindow messages={messages} isLoading={isLoading} />
        <MessageInput onSendMessage={handleSendMessage} disabled={isLoading} />
      </div>
    </main>
  )
}
