'use client'

import React from "react"

import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button'

interface MessageInputProps {
  onSendMessage: (message: string) => void
  disabled?: boolean
}

export default function MessageInput({ onSendMessage, disabled }: MessageInputProps) {
  const [input, setInput] = useState('')
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim() && !disabled) {
      onSendMessage(input.trim())
      setInput('')
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto'
      }
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && !disabled) {
      e.preventDefault()
      handleSubmit(e as unknown as React.FormEvent)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value)
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px'
    }
  }

  return (
    <div className="border-t border-border/30 bg-background/50 backdrop-blur-sm flex-shrink-0 py-4">
      <div className="max-w-2xl mx-auto px-8">
        <form onSubmit={handleSubmit} className="flex gap-3">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={handleInputChange}
            onKeyDown={handleKeyDown}
            placeholder="说点什么..."
            disabled={disabled}
            rows={1}
            className="flex-1 px-4 py-3 bg-card border border-border/30 rounded-lg text-foreground placeholder-muted-foreground/50 focus:outline-none focus:ring-1 focus:ring-primary resize-none text-base leading-relaxed disabled:opacity-50"
            style={{ minHeight: '44px', maxHeight: '120px' }}
          />
          <Button
            type="submit"
            disabled={disabled || !input.trim()}
            className="px-6 h-12 bg-primary hover:bg-primary/90 text-primary-foreground disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
            size="sm"
          >
            <span className="text-sm font-medium">发送</span>
          </Button>
        </form>
      </div>
    </div>
  )
}
